export const colors = {
  primary: '#2563EB',
  background: '#FFFFFF',
  textPrimary: '#111827',
  textSecondary: '#6B7280',
};
