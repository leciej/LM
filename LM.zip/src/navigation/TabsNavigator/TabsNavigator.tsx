import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import { ProductsScreen } from '../../screens/ProductsScreen';
import { CartScreen } from '../../screens/CartScreen';
import { ProfileScreen } from '../../screens/ProfileScreen';

import { useCartStore } from '../../features/cart/store/cartStore';

const Tab = createBottomTabNavigator();

export function TabsNavigator() {
  // 🔥 REAKTYWNY odczyt ze store
  const cartTotal = useCartStore(state => state.totalItems);

  return (
    <Tab.Navigator>
      <Tab.Screen
        name="Products"
        component={ProductsScreen}
        options={{ title: 'Produkty' }}
      />

      <Tab.Screen
        name="Cart"
        component={CartScreen}
        options={{
          title: 'Koszyk',
          tabBarBadge: cartTotal > 0 ? cartTotal : undefined,
        }}
      />

      <Tab.Screen
        name="Profile"
        component={ProfileScreen}
        options={{ title: 'Profil' }}
      />
    </Tab.Navigator>
  );
}
