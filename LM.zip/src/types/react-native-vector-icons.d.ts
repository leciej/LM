declare module 'react-native-vector-icons/Ionicons' {
  const Ionicons: any;
  export default Ionicons;
}
