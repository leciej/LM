import React from 'react';
import { View, Text } from 'react-native';

export function GalleryScreen() {
  return (
    <View>
      <Text>Galeria obrazów</Text>
    </View>
  );
}
