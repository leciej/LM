import type { Product } from '../../products/mockProducts';

export type Source = 'PRODUCTS' | 'GALLERY';

export type CartItem = Product & {
  cartItemId: string;
  quantity: number;
  source: Source;
};

let cart: CartItem[] = [];

const listeners = new Set<() => void>();
const notify = () => listeners.forEach(l => l());

export function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

/* utils */
const createCartItemId = () =>
  Math.random().toString(36).slice(2);

/* ADD */
export function addItemToCart(
  product: Product,
  source: Source
): void {
  const existing = cart.find(
    item =>
      item.id === product.id &&
      item.source === source
  );

  if (existing) {
    cart = cart.map(item =>
      item.cartItemId === existing.cartItemId
        ? { ...item, quantity: item.quantity + 1 }
        : item
    );
  } else {
    cart = [
      ...cart,
      {
        ...product,
        cartItemId: createCartItemId(),
        quantity: 1,
        source,
      },
    ];
  }

  notify();
}

/* READ */
export function getCartSnapshot(): CartItem[] {
  return cart;
}

export function getCartItemsCount(): number {
  return cart.reduce((s, i) => s + i.quantity, 0);
}

export function getProductsCount(): number {
  return cart
    .filter(i => i.source === 'PRODUCTS')
    .reduce((s, i) => s + i.quantity, 0);
}

export function getGalleryCount(): number {
  return cart
    .filter(i => i.source === 'GALLERY')
    .reduce((s, i) => s + i.quantity, 0);
}

/* UPDATE / DELETE */
export function decreaseItemInCart(cartItemId: string): void {
  const existing = cart.find(i => i.cartItemId === cartItemId);
  if (!existing) return;

  if (existing.quantity <= 1) {
    cart = cart.filter(i => i.cartItemId !== cartItemId);
  } else {
    cart = cart.map(i =>
      i.cartItemId === cartItemId
        ? { ...i, quantity: i.quantity - 1 }
        : i
    );
  }

  notify();
}

export function removeItemFromCart(cartItemId: string): void {
  cart = cart.filter(i => i.cartItemId !== cartItemId);
  notify();
}

export function clearCart(): void {
  cart = [];
  notify();
}
