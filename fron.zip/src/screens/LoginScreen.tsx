import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  TextInput,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { useAuth } from '../auth/AuthContext';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation/AppNavigator';

import { UsersApi } from '@/api/users/usersApi';

type NavigationProp = NativeStackNavigationProp<
  RootStackParamList,
  'Login'
>;

type LoginMode = 'USER' | 'ADMIN' | null;

export function LoginScreen() {
  const { loginAsGuest, login } = useAuth();
  const navigation = useNavigation<NavigationProp>();

  const [mode, setMode] = useState<LoginMode>(
    null
  );

  const [loginOrEmail, setLoginOrEmail] =
    useState('');
  const [password, setPassword] =
    useState('');
  const [loading, setLoading] =
    useState(false);
  const [error, setError] =
    useState<string | null>(null);

  /* =========================
     LOGIN (USER / ADMIN)
     ========================= */

  const handleLogin = async () => {
    if (!loginOrEmail || !password) {
      setError('Podaj login/email i hasło');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const user = await UsersApi.login({
        loginOrEmail: loginOrEmail.trim(),
        password,
      });

      login(user);
    } catch {
      Alert.alert(
        'Błąd logowania',
        'Niepoprawne dane logowania'
      );
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setLoginOrEmail('');
    setPassword('');
    setError(null);
    setMode(null);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>
        Guten Tag twoja mać!
      </Text>

      {/* GOŚĆ */}
      <Pressable
        style={[styles.button, styles.guestButton]}
        onPress={loginAsGuest}
      >
        <Text style={styles.buttonText}>
          Zaloguj jako gość
        </Text>
      </Pressable>

      {/* ADMIN */}
      {!mode && (
        <Pressable
          style={[
            styles.button,
            styles.adminButton,
          ]}
          onPress={() => setMode('ADMIN')}
        >
          <Text style={styles.buttonText}>
            Zaloguj jako admin
          </Text>
        </Pressable>
      )}

      {/* USER */}
      {!mode && (
        <Pressable
          style={[
            styles.button,
            styles.userButton,
          ]}
          onPress={() => setMode('USER')}
        >
          <Text style={styles.buttonText}>
            Zaloguj jako użytkownik
          </Text>
        </Pressable>
      )}

      {/* FORM */}
      {mode && (
        <>
          <Text style={styles.sectionTitle}>
            {mode === 'ADMIN'
              ? 'Logowanie admina'
              : 'Logowanie użytkownika'}
          </Text>

          <TextInput
            placeholder="Login lub email"
            value={loginOrEmail}
            onChangeText={setLoginOrEmail}
            autoCapitalize="none"
            style={styles.input}
          />

          <TextInput
            placeholder="Hasło"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            style={styles.input}
          />

          {error && (
            <Text style={styles.error}>
              {error}
            </Text>
          )}

          <Pressable
            style={[
              styles.button,
              mode === 'ADMIN'
                ? styles.adminButton
                : styles.userButton,
              loading && styles.disabled,
            ]}
            onPress={handleLogin}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.buttonText}>
                Zaloguj
              </Text>
            )}
          </Pressable>

          <Pressable onPress={resetForm}>
            <Text style={styles.cancel}>
              Anuluj
            </Text>
          </Pressable>
        </>
      )}

      {/* REGISTER */}
      {!mode && (
        <Pressable
          style={[
            styles.button,
            styles.registerButton,
          ]}
          onPress={() =>
            navigation.navigate('Register')
          }
        >
          <Text style={styles.buttonText}>
            Zarejestruj się
          </Text>
        </Pressable>
      )}
    </View>
  );
}

/* =========================
   STYLES
   ========================= */

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 24,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 24,
    textAlign: 'center',
  },
  sectionTitle: {
    marginTop: 20,
    marginBottom: 8,
    fontSize: 16,
    fontWeight: '700',
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 12,
    borderRadius: 6,
    marginBottom: 12,
  },
  button: {
    padding: 14,
    borderRadius: 6,
    marginBottom: 12,
    alignItems: 'center',
  },
  guestButton: {
    backgroundColor: '#607d8b',
  },
  userButton: {
    backgroundColor: '#1976d2',
  },
  adminButton: {
    backgroundColor: '#455a64',
  },
  registerButton: {
    backgroundColor: '#2e7d32',
    marginTop: 12,
  },
  buttonText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 16,
  },
  error: {
    color: '#b71c1c',
    textAlign: 'center',
    marginBottom: 8,
    fontWeight: '600',
  },
  cancel: {
    textAlign: 'center',
    color: '#555',
    marginTop: 4,
  },
  disabled: {
    opacity: 0.6,
  },
});
