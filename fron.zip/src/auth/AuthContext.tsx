import React, {
  createContext,
  useContext,
  useState,
  type ReactNode,
} from 'react';

/* =========================
   TYPY
   ========================= */

export type UserRole = 'USER' | 'ADMIN';

export type User = {
  id: number;
  name: string;
  email: string;
  role: UserRole;
};

type AuthContextType = {
  isLoggedIn: boolean;
  role: UserRole | null;
  user: User | null;

  loginAsGuest: () => void;
  login: (user: User) => void;
  register: (user: User) => void;
  logout: () => void;
};

/* =========================
   CONTEXT
   ========================= */

const AuthContext =
  createContext<AuthContextType | undefined>(
    undefined
  );

type AuthProviderProps = {
  children: ReactNode;
};

/* =========================
   PROVIDER
   ========================= */

export function AuthProvider({
  children,
}: AuthProviderProps) {
  const [user, setUser] =
    useState<User | null>(null);
  const [role, setRole] =
    useState<UserRole | null>(null);
  const [isLoggedIn, setIsLoggedIn] =
    useState(false);

  const loginAsGuest = () => {
    const guest: User = {
      id: 0,
      name: 'Gość',
      email: 'guest@demo.pl',
      role: 'USER',
    };

    setUser(guest);
    setRole('USER');
    setIsLoggedIn(true);
  };

  const login = (loggedUser: User) => {
    setUser(loggedUser);
    setRole(loggedUser.role);
    setIsLoggedIn(true);
  };

  const register = (newUser: User) => {
    setUser(newUser);
    setRole(newUser.role);
    setIsLoggedIn(true);
  };

  const logout = () => {
    setUser(null);
    setRole(null);
    setIsLoggedIn(false);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        role,
        isLoggedIn,
        loginAsGuest,
        login,
        register,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

/* =========================
   HOOK
   ========================= */

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error(
      'useAuth must be used inside AuthProvider'
    );
  }
  return context;
}
